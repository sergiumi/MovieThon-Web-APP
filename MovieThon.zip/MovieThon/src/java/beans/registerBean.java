package beans;

import entities.Users;
import entities.UsersJpaController;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import jakarta.annotation.Resource;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.PersistenceUnit;
import jakarta.transaction.UserTransaction;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

@Named
@SessionScoped // This bean will live throughout the user's session
public class registerBean implements Serializable {

    private static final long serialVersionUID = 1L;

    // Regex pattern to validate email format
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$");

    // User input fields for registration
    private String firstName;
    private String lastName;
    private String email;
    private String password;
    private String confirmPassword;

    // Flags to track registration state
    private boolean registrationInProgress = false;
    private boolean registrationSuccess = false;

    // Injecting persistence context and transaction manager
    @PersistenceUnit(unitName = "MovieThonPU")
    private EntityManagerFactory emf;

    @Resource
    private UserTransaction utx;

    // Getters and setters for form fields
    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getConfirmPassword() { return confirmPassword; }
    public void setConfirmPassword(String confirmPassword) { this.confirmPassword = confirmPassword; }

    public boolean isRegistrationInProgress() { return registrationInProgress; }
    public void setRegistrationInProgress(boolean registrationInProgress) { this.registrationInProgress = registrationInProgress; }

    public boolean isRegistrationSuccess() { return registrationSuccess; }
    public void setRegistrationSuccess(boolean registrationSuccess) { this.registrationSuccess = registrationSuccess; }

    // Validates the user's form input before saving to database
    private boolean validateInput() {
        boolean valid = true;
        FacesContext context = FacesContext.getCurrentInstance();

        // First name validation
        if (firstName == null || firstName.trim().length() < 2) {
            context.addMessage("registerForm:firstName",
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "First name must be at least 2 characters", null));
            valid = false;
        }

        // Last name validation
        if (lastName == null || lastName.trim().length() < 2) {
            context.addMessage("registerForm:lastName",
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Last name must be at least 2 characters", null));
            valid = false;
        }

        // Email validation
        if (email == null || !EMAIL_PATTERN.matcher(email).matches()) {
            context.addMessage("registerForm:email",
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Please enter a valid email address", null));
            valid = false;
        }

        // Password validation
        if (!isPasswordValid(password)) {
            context.addMessage("registerForm:password",
                new FacesMessage(FacesMessage.SEVERITY_ERROR,
                    "Password must contain at least 6 characters, one uppercase letter, one lowercase letter, and one number", null));
            valid = false;
        }

        // Password confirmation
        if (!password.equals(confirmPassword)) {
            context.addMessage("registerForm:confirmPassword",
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Passwords do not match", null));
            valid = false;
        }

        return valid;
    }

    // Handles the registration logic
    public String register() {
        try {
            registrationInProgress = true;
            registrationSuccess = false; // Reset flag before starting

            // Validate form inputs
            if (!validateInput()) {
                return null; // Stop process if input is invalid
            }

            // Instantiate user JPA controller
            UsersJpaController userController = new UsersJpaController(utx, emf);

            // Check if email is already registered
            List<Users> existingUsers = userController.findUsersEntities();
            for (Users user : existingUsers) {
                if (user.getEmail().equals(email)) {
                    FacesContext.getCurrentInstance().addMessage("registerForm:email",
                        new FacesMessage(FacesMessage.SEVERITY_ERROR, "Email already registered", null));
                    return null;
                }
            }

            // Create new user and set properties
            Users newUser = new Users();
            newUser.setFname(firstName.trim());
            newUser.setLname(lastName.trim());
            newUser.setEmail(email.trim().toLowerCase());
            newUser.setPassword(password); // Note: password should be hashed in real applications
            newUser.setJoindate(new Date());
            newUser.setRole("user"); // Assign default role

            // Save user in the database
            userController.create(newUser);

            // Set success flag and clear form
            registrationSuccess = true;
            clearForm();

            // Stay on same page to show success message
            return null;

        } catch (Exception e) {
            // Handle errors and show feedback
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR,
                    "Error during registration: " + e.getMessage(), null));
            return null;
        } finally {
            registrationInProgress = false;
        }
    }

    // Validates password strength
    private boolean isPasswordValid(String password) {
        if (password == null || password.length() < 6) {
            return false;
        }

        boolean hasUppercase = false;
        boolean hasLowercase = false;
        boolean hasNumber = false;

        // Check password character requirements
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasUppercase = true;
            if (Character.isLowerCase(c)) hasLowercase = true;
            if (Character.isDigit(c)) hasNumber = true;
        }

        // Show message if any condition is not met
        if (!hasUppercase || !hasLowercase || !hasNumber) {
            FacesContext.getCurrentInstance().addMessage("registerForm:password",
                new FacesMessage(FacesMessage.SEVERITY_ERROR,
                    "Password must contain at least one uppercase letter, one lowercase letter, and one number", null));
            return false;
        }

        return true;
    }

    // Clears the form fields after successful registration
    private void clearForm() {
        this.firstName = null;
        this.lastName = null;
        this.email = null;
        this.password = null;
        this.confirmPassword = null;
    }

    // Used to check if registration was successful from another page (e.g., login)
    public boolean wasRegistrationSuccessful() {
        Object success = FacesContext.getCurrentInstance().getExternalContext()
            .getSessionMap().get("registrationSuccess");

        if (success != null && (Boolean) success) {
            // Remove flag after checking to avoid repeat messages
            FacesContext.getCurrentInstance().getExternalContext()
                .getSessionMap().remove("registrationSuccess");
            return true;
        }
        return false;
    }
}
