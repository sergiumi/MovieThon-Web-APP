/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

/**
 *
 * @author mitas
 */

import entities.Movies;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.List;

@Named("topMovies")
@SessionScoped
public class topMovies implements Serializable {

    private List<Movies> topMovies; // To store top movies
    private boolean showTopMovies = false; // Flag to toggle the visibility of top movies section
    
    @PersistenceContext(unitName = "MovieThonPU") // Replace with your persistence unit name
    private EntityManager em;

    // Fetch top movies based on ratings
    public void loadTopMovies() {
        TypedQuery<Movies> query = em.createQuery(
            "SELECT m FROM Movies m ORDER BY m.rating DESC", 
            Movies.class
        );
        query.setMaxResults(10); // Limit to the top 10 movies
        topMovies = query.getResultList();

        // Set the flag to show the top movies
        showTopMovies = true; // This ensures the top movies section is rendered
    }
    
    // Method to format release date
    public String formatReleaseDate(Movies movie) {
        if (movie.getReleasedate() != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            return sdf.format(movie.getReleasedate());
        }
        return ""; // Return an empty string if releaseDate is null
    }

    // Method to navigate to the page that shows top movies
    public String showTopMoviesPage() {
        loadTopMovies(); // Load top movies
        return "/topMovies.xhtml?faces-redirect=true"; // Navigate to topMovies.xhtml after loading
    }

    public List<Movies> getTopMovies() {
        return topMovies;
    }

    public void setTopMovies(List<Movies> topMovies) {
        this.topMovies = topMovies;
    }

    public boolean isShowTopMovies() {
        return showTopMovies;
    }

    public void setShowTopMovies(boolean showTopMovies) {
        this.showTopMovies = showTopMovies;
    }
}

