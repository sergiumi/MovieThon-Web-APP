package beans;
import entities.Movies;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Named("newMovies")
@SessionScoped
public class newMovies implements Serializable {
    
    private List<Movies> newMovies;   // To store new movies
    private boolean showNewMovies = false; // Flag to toggle the visibility of new movies section
    
    @PersistenceContext(unitName = "MovieThonPU") // Replace with your actual persistence unit name
    private EntityManager em;
   
    // Method to format release date
    public String formatReleaseDate(Movies movie) {
        if (movie.getReleasedate() != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            return sdf.format(movie.getReleasedate());
        }
        return ""; // Return an empty string if releaseDate is null
    }
    
    // Fetch movies released within the last year
    public void loadNewMovies() {
        Date currentDate = new Date(); 
        long oneYearInMillis = 365L * 24L * 60L * 60L * 1000L; 
        Date oneYearAgo = new Date(currentDate.getTime() - oneYearInMillis); 
        TypedQuery<Movies> query = em.createQuery(
            "SELECT m FROM Movies m WHERE m.releasedate > :oneYearAgo ORDER BY m.releasedate DESC",
            Movies.class
        );
        query.setParameter("oneYearAgo", oneYearAgo);
        newMovies = query.getResultList();
        
        // Set the flag to show the new movies
        showNewMovies = true;  // This ensures the new movies section is rendered
    }
    
    // Method to navigate to the page that shows new movies
    public String showNewMoviesPage() {
        loadNewMovies();  // Load new movies
        return "/newMovies.xhtml?faces-redirect=true";  // Navigate to newMovies.xhtml after loading
    }
  
    public List<Movies> getNewMovies() {
        return newMovies;
    }
    
    public void setNewMovies(List<Movies> newMovies) {
        this.newMovies = newMovies;
    }
    
    public boolean isShowNewMovies() {
        return showNewMovies;
    }
    
    public void setShowNewMovies(boolean showNewMovies) {
        this.showNewMovies = showNewMovies;
    }
}