package beans;

import entities.Movies;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.List;
import jakarta.faces.event.AjaxBehaviorEvent;

@Named("searchBean")
@SessionScoped
public class searchBean implements Serializable {

    private String searchQuery;
    private List<Movies> searchResults;
    private boolean isSearching = false;

    @PersistenceContext(unitName = "MovieThonPU")
    private EntityManager em;

    // AJAX-enabled search method for real-time search
    public void searchInIndex(AjaxBehaviorEvent event) {
        if (searchQuery != null && !searchQuery.trim().isEmpty()) {
            isSearching = true;
            performSearch();
        } else {
            isSearching = false;
            searchResults = null;
        }
    }

    // Standard search method for non-AJAX calls
    public String search() {
        performSearch();
        return "/search.xhtml?faces-redirect=true";
    }

    // Common search logic
    private void performSearch() {
        if (searchQuery != null && !searchQuery.trim().isEmpty()) {
            TypedQuery<Movies> query = em.createQuery(
                "SELECT m FROM Movies m WHERE LOWER(m.title) LIKE LOWER(:searchText) " +
                "OR LOWER(m.genre) LIKE LOWER(:searchText) " +
                "OR LOWER(m.language) LIKE LOWER(:searchText) " +
                "ORDER BY m.rating DESC",
                Movies.class
            );
            query.setParameter("searchText", "%" + searchQuery.trim() + "%");
            searchResults = query.getResultList();
        } else {
            searchResults = null;
        }
    }

    public String formatReleaseDate(Movies movie) {
        if (movie.getReleasedate() != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("MMMM dd, yyyy");
            return sdf.format(movie.getReleasedate());
        }
        return "";
    }

    

    // Getters and Setters
    public String getSearchQuery() {
        return searchQuery;
    }

    public void setSearchQuery(String searchQuery) {
        this.searchQuery = searchQuery;
    }

    public List<Movies> getSearchResults() {
        return searchResults;
    }

    public void setSearchResults(List<Movies> searchResults) {
        this.searchResults = searchResults;
    }


    public boolean isSearching() {
        return isSearching;
    }

    public void setSearching(boolean searching) {
        isSearching = searching;
    }
}