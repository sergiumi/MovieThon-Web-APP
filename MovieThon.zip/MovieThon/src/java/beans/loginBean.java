package beans;

/**
 *
 * @author mitas
 */

// Importing necessary classes for JSF, JPA, and transactions
import entities.Users;
import entities.UsersJpaController;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import jakarta.annotation.Resource;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.PersistenceUnit;
import jakarta.persistence.TypedQuery;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.transaction.UserTransaction;
import java.io.Serializable;
import java.util.List;

@Named("loginBean") // JSF annotation to allow access via #{loginBean}
@SessionScoped // The bean is alive during the entire user session
public class loginBean implements Serializable {

    private static final long serialVersionUID = 1L;

    // --- Fields for login credentials and session state ---
    private String email;           // User's email (used for login)
    private String password;        // User's password
    private Users currentUser;      // The currently logged-in user
    private boolean isLoggedIn = false; // Login status flag

    // --- JPA and Transaction management ---
    @PersistenceUnit(unitName = "MovieThonPU")
    private EntityManagerFactory emf; // EntityManagerFactory for DB access

    @Resource
    private UserTransaction utx; // Handles transaction boundaries

    // --- Helper method to access the Users JPA controller ---
    private UsersJpaController getUsersController() {
        return new UsersJpaController(utx, emf);
    }

    // --- Getters and Setters for JSF binding ---
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }

    public Users getCurrentUser() {
        return currentUser;
    }

    public boolean isLoggedIn() {
        return isLoggedIn;
    }

    /**
     * Attempts to authenticate the user using email and password.
     * Redirects to different pages based on user role.
     */
    public String login() {
        try {
            System.out.println("Login attempt with email: " + email);

            EntityManager em = emf.createEntityManager();
            try {
                // Named query to find user by email
                TypedQuery<Users> query = em.createNamedQuery("Users.findByEmail", Users.class);
                query.setParameter("email", email);
                List<Users> users = query.getResultList();

                System.out.println("Found users: " + users.size());

                // If a user exists, check the password
                if (!users.isEmpty()) {
                    Users user = users.get(0);

                    System.out.println("Checking password for user: " + user.getEmail());

                    // NOTE: Password should be hashed in production
                    if (user.getPassword().equals(password)) {
                        currentUser = user;
                        isLoggedIn = true;

                        System.out.println("Login successful for user: " + user.getEmail() + " with role: " + user.getRole());

                        // Redirect based on user role
                        if ("admin".equals(user.getRole())) {
                            return "/admin?faces-redirect=true";
                        } else {
                            return "/index?faces-redirect=true";
                        }
                    }
                }

                // Show error if login fails
                System.out.println("Login failed: Invalid credentials");
                FacesContext.getCurrentInstance().addMessage(
                    null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Invalid email or password", "Please try again")
                );
                return null;

            } finally {
                em.close(); // Always close EntityManager
            }

        } catch (Exception e) {
            System.out.println("Login error: " + e.getMessage());
            e.printStackTrace();

            FacesContext.getCurrentInstance().addMessage(
                null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error during login", "Please try again later")
            );
            return null;
        }
    }

    /**
     * Clears the email and password fields, usually after logout or form reset.
     */
    public void clearFields() {
        this.email = "";
        this.password = "";
    }

    /**
     * Logs the user out by clearing the session data.
     * Invalidates session and redirects to home page.
     */
    public String logout() {
        try {
            this.email = "";
            this.password = "";
            this.currentUser = null;
            this.isLoggedIn = false;

            FacesContext context = FacesContext.getCurrentInstance();
            context.getExternalContext().invalidateSession(); // Ends session
            context.getExternalContext().getSession(true);    // Starts a new session

            return "/index?faces-redirect=true"; // Redirect to home
        } catch (Exception e) {
            return "/index?faces-redirect=true";
        }
    }

    /**
     * Returns the full name of the logged-in user.
     */
    public String getUserFullName() {
        if (currentUser != null) {
            return currentUser.getFname() + " " + currentUser.getLname();
        }
        return "";
    }

    /**
     * Returns the role of the logged-in user.
     */
    public String getUserRole() {
        if (currentUser != null) {
            return currentUser.getRole();
        }
        return "";
    }

    /**
     * Checks if the logged-in user has a specific role.
     */
    public boolean hasRole(String role) {
        return currentUser != null && role.equals(currentUser.getRole());
    }

    /**
     * Manually sets a user as logged in (used for testing or admin override).
     */
    public String loginAsUser(Users selectedUser) {
        this.currentUser = selectedUser;
        this.isLoggedIn = true;
        return "/index?faces-redirect=true";
    }
}
