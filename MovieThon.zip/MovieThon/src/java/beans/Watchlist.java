package beans;

/**
 *
 * @author mitas
 */

import jakarta.inject.Named;
import jakarta.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import entities.Movies;
import jakarta.annotation.PostConstruct;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;

@Named
@SessionScoped // Bean persists across multiple HTTP requests within the same session
public class Watchlist implements Serializable {

    // List to store movies added to the user's watchlist
    private List<Movies> watchlistMovies;

    // Initialize the watchlist after the bean is constructed
    @PostConstruct
    public void init() {
        watchlistMovies = new ArrayList<>();
    }

    // Getter for the watchlist
    public List<Movies> getWatchlistMovies() {
        return watchlistMovies;
    }

    // Setter for the watchlist
    public void setWatchlistMovies(List<Movies> watchlistMovies) {
        this.watchlistMovies = watchlistMovies;
    }

    // Add a movie to the watchlist if it's not already present
    public void addToWatchlist(Movies movie) {
        if (!watchlistMovies.contains(movie)) {
            watchlistMovies.add(movie);
            // Show success message to user
            FacesContext.getCurrentInstance().addMessage(null, 
                new FacesMessage(FacesMessage.SEVERITY_INFO, 
                    "Success", "Movie added to watchlist"));
        } else {
            // Show warning if movie is already in the list
            FacesContext.getCurrentInstance().addMessage(null, 
                new FacesMessage(FacesMessage.SEVERITY_WARN, 
                    "Warning", "Movie is already in watchlist"));
        }
    }

    // Remove a movie from the watchlist by movie ID
    public void removeFromWatchlist(Long movieId) {
        watchlistMovies.removeIf(m -> m.getMovieid().equals(movieId));
        // Show success message after removal
        FacesContext.getCurrentInstance().addMessage(null, 
            new FacesMessage(FacesMessage.SEVERITY_INFO, 
                "Success", "Movie removed from watchlist"));
    }

    // Check if a movie is already in the watchlist by ID
    public boolean isInWatchlist(Long movieId) {
        return watchlistMovies.stream()
                .anyMatch(m -> m.getMovieid().equals(movieId));
    }
}
