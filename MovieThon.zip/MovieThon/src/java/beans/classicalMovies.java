
/**
 *
 * @author mitas
 */

package beans;

import entities.Movies;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Named("classicalMovies")
@SessionScoped
public class classicalMovies implements Serializable {

    private List<Movies> classicalMovies; // To store classical movies
    private boolean showClassicalMovies = false; // Flag to toggle visibility of classical movies section
    
    @PersistenceContext(unitName = "MovieThonPU") // Replace with your actual persistence unit name
    private EntityManager em;

    // Method to format release date
    public String formatReleaseDate(Movies movie) {
        if (movie.getReleasedate() != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            return sdf.format(movie.getReleasedate());
        }
        return ""; // Return an empty string if releaseDate is null
    }

    // Fetch movies released up until 1980
    public void loadClassicalMovies() {
        TypedQuery<Movies> query = em.createQuery(
            "SELECT m FROM Movies m WHERE m.releasedate <= :cutoffYear ORDER BY m.releasedate ASC",
            Movies.class
        );
        // Setting the cutoff year as 1980
        query.setParameter("cutoffYear", new Date(80, 11, 31)); // December 31, 1980
        classicalMovies = query.getResultList();

        // Set the flag to show the classical movies
        showClassicalMovies = true; // This ensures the classical movies section is rendered
    }

    // Method to navigate to the page that shows classical movies
    public String showClassicalMoviesPage() {
        loadClassicalMovies(); // Load classical movies
        return "/classicalMovies.xhtml?faces-redirect=true"; // Navigate to classicalMovies.xhtml after loading
    }

    public List<Movies> getClassicalMovies() {
        return classicalMovies;
    }

    public void setClassicalMovies(List<Movies> classicalMovies) {
        this.classicalMovies = classicalMovies;
    }

    public boolean isShowClassicalMovies() {
        return showClassicalMovies;
    }

    public void setShowClassicalMovies(boolean showClassicalMovies) {
        this.showClassicalMovies = showClassicalMovies;
    }
}
