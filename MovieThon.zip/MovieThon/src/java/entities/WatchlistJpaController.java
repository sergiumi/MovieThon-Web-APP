/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entities;

import entities.exceptions.NonexistentEntityException;
import entities.exceptions.RollbackFailureException;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import java.io.Serializable;
import jakarta.persistence.Query;
import jakarta.persistence.EntityNotFoundException;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import jakarta.transaction.UserTransaction;
import java.util.List;

/**
 *
 * @author mitas
 */
public class WatchlistJpaController implements Serializable {

    public WatchlistJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Watchlist watchlist) throws RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Movies movieid = watchlist.getMovieid();
            if (movieid != null) {
                movieid = em.getReference(movieid.getClass(), movieid.getMovieid());
                watchlist.setMovieid(movieid);
            }
            Users userid = watchlist.getUserid();
            if (userid != null) {
                userid = em.getReference(userid.getClass(), userid.getUserid());
                watchlist.setUserid(userid);
            }
            em.persist(watchlist);
            if (movieid != null) {
                movieid.getWatchlistCollection().add(watchlist);
                movieid = em.merge(movieid);
            }
            if (userid != null) {
                userid.getWatchlistCollection().add(watchlist);
                userid = em.merge(userid);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Watchlist watchlist) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Watchlist persistentWatchlist = em.find(Watchlist.class, watchlist.getWatchlistid());
            Movies movieidOld = persistentWatchlist.getMovieid();
            Movies movieidNew = watchlist.getMovieid();
            Users useridOld = persistentWatchlist.getUserid();
            Users useridNew = watchlist.getUserid();
            if (movieidNew != null) {
                movieidNew = em.getReference(movieidNew.getClass(), movieidNew.getMovieid());
                watchlist.setMovieid(movieidNew);
            }
            if (useridNew != null) {
                useridNew = em.getReference(useridNew.getClass(), useridNew.getUserid());
                watchlist.setUserid(useridNew);
            }
            watchlist = em.merge(watchlist);
            if (movieidOld != null && !movieidOld.equals(movieidNew)) {
                movieidOld.getWatchlistCollection().remove(watchlist);
                movieidOld = em.merge(movieidOld);
            }
            if (movieidNew != null && !movieidNew.equals(movieidOld)) {
                movieidNew.getWatchlistCollection().add(watchlist);
                movieidNew = em.merge(movieidNew);
            }
            if (useridOld != null && !useridOld.equals(useridNew)) {
                useridOld.getWatchlistCollection().remove(watchlist);
                useridOld = em.merge(useridOld);
            }
            if (useridNew != null && !useridNew.equals(useridOld)) {
                useridNew.getWatchlistCollection().add(watchlist);
                useridNew = em.merge(useridNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = watchlist.getWatchlistid();
                if (findWatchlist(id) == null) {
                    throw new NonexistentEntityException("The watchlist with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Watchlist watchlist;
            try {
                watchlist = em.getReference(Watchlist.class, id);
                watchlist.getWatchlistid();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The watchlist with id " + id + " no longer exists.", enfe);
            }
            Movies movieid = watchlist.getMovieid();
            if (movieid != null) {
                movieid.getWatchlistCollection().remove(watchlist);
                movieid = em.merge(movieid);
            }
            Users userid = watchlist.getUserid();
            if (userid != null) {
                userid.getWatchlistCollection().remove(watchlist);
                userid = em.merge(userid);
            }
            em.remove(watchlist);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Watchlist> findWatchlistEntities() {
        return findWatchlistEntities(true, -1, -1);
    }

    public List<Watchlist> findWatchlistEntities(int maxResults, int firstResult) {
        return findWatchlistEntities(false, maxResults, firstResult);
    }

    private List<Watchlist> findWatchlistEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Watchlist.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Watchlist findWatchlist(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Watchlist.class, id);
        } finally {
            em.close();
        }
    }

    public int getWatchlistCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Watchlist> rt = cq.from(Watchlist.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
