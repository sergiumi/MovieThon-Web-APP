/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entities;

import entities.exceptions.NonexistentEntityException;
import entities.exceptions.RollbackFailureException;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import java.io.Serializable;
import jakarta.persistence.Query;
import jakarta.persistence.EntityNotFoundException;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import jakarta.transaction.UserTransaction;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 *
 * @author mitas
 */
public class UsersJpaController implements Serializable {

    public UsersJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Users users) throws RollbackFailureException, Exception {
        if (users.getWatchlistCollection() == null) {
            users.setWatchlistCollection(new ArrayList<Watchlist>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Collection<Watchlist> attachedWatchlistCollection = new ArrayList<Watchlist>();
            for (Watchlist watchlistCollectionWatchlistToAttach : users.getWatchlistCollection()) {
                watchlistCollectionWatchlistToAttach = em.getReference(watchlistCollectionWatchlistToAttach.getClass(), watchlistCollectionWatchlistToAttach.getWatchlistid());
                attachedWatchlistCollection.add(watchlistCollectionWatchlistToAttach);
            }
            users.setWatchlistCollection(attachedWatchlistCollection);
            em.persist(users);
            for (Watchlist watchlistCollectionWatchlist : users.getWatchlistCollection()) {
                Users oldUseridOfWatchlistCollectionWatchlist = watchlistCollectionWatchlist.getUserid();
                watchlistCollectionWatchlist.setUserid(users);
                watchlistCollectionWatchlist = em.merge(watchlistCollectionWatchlist);
                if (oldUseridOfWatchlistCollectionWatchlist != null) {
                    oldUseridOfWatchlistCollectionWatchlist.getWatchlistCollection().remove(watchlistCollectionWatchlist);
                    oldUseridOfWatchlistCollectionWatchlist = em.merge(oldUseridOfWatchlistCollectionWatchlist);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Users users) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Users persistentUsers = em.find(Users.class, users.getUserid());
            Collection<Watchlist> watchlistCollectionOld = persistentUsers.getWatchlistCollection();
            Collection<Watchlist> watchlistCollectionNew = users.getWatchlistCollection();
            Collection<Watchlist> attachedWatchlistCollectionNew = new ArrayList<Watchlist>();
            for (Watchlist watchlistCollectionNewWatchlistToAttach : watchlistCollectionNew) {
                watchlistCollectionNewWatchlistToAttach = em.getReference(watchlistCollectionNewWatchlistToAttach.getClass(), watchlistCollectionNewWatchlistToAttach.getWatchlistid());
                attachedWatchlistCollectionNew.add(watchlistCollectionNewWatchlistToAttach);
            }
            watchlistCollectionNew = attachedWatchlistCollectionNew;
            users.setWatchlistCollection(watchlistCollectionNew);
            users = em.merge(users);
            for (Watchlist watchlistCollectionOldWatchlist : watchlistCollectionOld) {
                if (!watchlistCollectionNew.contains(watchlistCollectionOldWatchlist)) {
                    watchlistCollectionOldWatchlist.setUserid(null);
                    watchlistCollectionOldWatchlist = em.merge(watchlistCollectionOldWatchlist);
                }
            }
            for (Watchlist watchlistCollectionNewWatchlist : watchlistCollectionNew) {
                if (!watchlistCollectionOld.contains(watchlistCollectionNewWatchlist)) {
                    Users oldUseridOfWatchlistCollectionNewWatchlist = watchlistCollectionNewWatchlist.getUserid();
                    watchlistCollectionNewWatchlist.setUserid(users);
                    watchlistCollectionNewWatchlist = em.merge(watchlistCollectionNewWatchlist);
                    if (oldUseridOfWatchlistCollectionNewWatchlist != null && !oldUseridOfWatchlistCollectionNewWatchlist.equals(users)) {
                        oldUseridOfWatchlistCollectionNewWatchlist.getWatchlistCollection().remove(watchlistCollectionNewWatchlist);
                        oldUseridOfWatchlistCollectionNewWatchlist = em.merge(oldUseridOfWatchlistCollectionNewWatchlist);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = users.getUserid();
                if (findUsers(id) == null) {
                    throw new NonexistentEntityException("The users with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Users users;
            try {
                users = em.getReference(Users.class, id);
                users.getUserid();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The users with id " + id + " no longer exists.", enfe);
            }
            Collection<Watchlist> watchlistCollection = users.getWatchlistCollection();
            for (Watchlist watchlistCollectionWatchlist : watchlistCollection) {
                watchlistCollectionWatchlist.setUserid(null);
                watchlistCollectionWatchlist = em.merge(watchlistCollectionWatchlist);
            }
            em.remove(users);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Users> findUsersEntities() {
        return findUsersEntities(true, -1, -1);
    }

    public List<Users> findUsersEntities(int maxResults, int firstResult) {
        return findUsersEntities(false, maxResults, firstResult);
    }

    private List<Users> findUsersEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Users.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Users findUsers(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Users.class, id);
        } finally {
            em.close();
        }
    }

    public int getUsersCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Users> rt = cq.from(Users.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
