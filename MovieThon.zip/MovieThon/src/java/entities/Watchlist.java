/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entities;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author mitas
 */
@Entity
@Table(name = "WATCHLIST")
@NamedQueries({
    @NamedQuery(name = "Watchlist.findAll", query = "SELECT w FROM Watchlist w"),
    @NamedQuery(name = "Watchlist.findByWatchlistid", query = "SELECT w FROM Watchlist w WHERE w.watchlistid = :watchlistid"),
    @NamedQuery(name = "Watchlist.findByCreatedat", query = "SELECT w FROM Watchlist w WHERE w.createdat = :createdat")})
public class Watchlist implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "WATCHLISTID")
    private Integer watchlistid;
    @Column(name = "CREATEDAT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdat;
    @JoinColumn(name = "MOVIEID", referencedColumnName = "MOVIEID")
    @ManyToOne
    private Movies movieid;
    @JoinColumn(name = "USERID", referencedColumnName = "USERID")
    @ManyToOne
    private Users userid;

    public Watchlist() {
    }

    public Watchlist(Integer watchlistid) {
        this.watchlistid = watchlistid;
    }

    public Integer getWatchlistid() {
        return watchlistid;
    }

    public void setWatchlistid(Integer watchlistid) {
        this.watchlistid = watchlistid;
    }

    public Date getCreatedat() {
        return createdat;
    }

    public void setCreatedat(Date createdat) {
        this.createdat = createdat;
    }

    public Movies getMovieid() {
        return movieid;
    }

    public void setMovieid(Movies movieid) {
        this.movieid = movieid;
    }

    public Users getUserid() {
        return userid;
    }

    public void setUserid(Users userid) {
        this.userid = userid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (watchlistid != null ? watchlistid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Watchlist)) {
            return false;
        }
        Watchlist other = (Watchlist) object;
        if ((this.watchlistid == null && other.watchlistid != null) || (this.watchlistid != null && !this.watchlistid.equals(other.watchlistid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Watchlist[ watchlistid=" + watchlistid + " ]";
    }
    
}
