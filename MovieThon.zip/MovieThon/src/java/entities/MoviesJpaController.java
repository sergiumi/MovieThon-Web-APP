/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entities;

import entities.exceptions.NonexistentEntityException;
import entities.exceptions.RollbackFailureException;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import java.io.Serializable;
import jakarta.persistence.Query;
import jakarta.persistence.EntityNotFoundException;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import jakarta.transaction.UserTransaction;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 *
 * @author mitas
 */
public class MoviesJpaController implements Serializable {

    public MoviesJpaController(UserTransaction utx, EntityManagerFactory emf) {
        this.utx = utx;
        this.emf = emf;
    }
    private UserTransaction utx = null;
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Movies movies) throws RollbackFailureException, Exception {
        if (movies.getWatchlistCollection() == null) {
            movies.setWatchlistCollection(new ArrayList<Watchlist>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Collection<Watchlist> attachedWatchlistCollection = new ArrayList<Watchlist>();
            for (Watchlist watchlistCollectionWatchlistToAttach : movies.getWatchlistCollection()) {
                watchlistCollectionWatchlistToAttach = em.getReference(watchlistCollectionWatchlistToAttach.getClass(), watchlistCollectionWatchlistToAttach.getWatchlistid());
                attachedWatchlistCollection.add(watchlistCollectionWatchlistToAttach);
            }
            movies.setWatchlistCollection(attachedWatchlistCollection);
            em.persist(movies);
            for (Watchlist watchlistCollectionWatchlist : movies.getWatchlistCollection()) {
                Movies oldMovieidOfWatchlistCollectionWatchlist = watchlistCollectionWatchlist.getMovieid();
                watchlistCollectionWatchlist.setMovieid(movies);
                watchlistCollectionWatchlist = em.merge(watchlistCollectionWatchlist);
                if (oldMovieidOfWatchlistCollectionWatchlist != null) {
                    oldMovieidOfWatchlistCollectionWatchlist.getWatchlistCollection().remove(watchlistCollectionWatchlist);
                    oldMovieidOfWatchlistCollectionWatchlist = em.merge(oldMovieidOfWatchlistCollectionWatchlist);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Movies movies) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Movies persistentMovies = em.find(Movies.class, movies.getMovieid());
            Collection<Watchlist> watchlistCollectionOld = persistentMovies.getWatchlistCollection();
            Collection<Watchlist> watchlistCollectionNew = movies.getWatchlistCollection();
            Collection<Watchlist> attachedWatchlistCollectionNew = new ArrayList<Watchlist>();
            for (Watchlist watchlistCollectionNewWatchlistToAttach : watchlistCollectionNew) {
                watchlistCollectionNewWatchlistToAttach = em.getReference(watchlistCollectionNewWatchlistToAttach.getClass(), watchlistCollectionNewWatchlistToAttach.getWatchlistid());
                attachedWatchlistCollectionNew.add(watchlistCollectionNewWatchlistToAttach);
            }
            watchlistCollectionNew = attachedWatchlistCollectionNew;
            movies.setWatchlistCollection(watchlistCollectionNew);
            movies = em.merge(movies);
            for (Watchlist watchlistCollectionOldWatchlist : watchlistCollectionOld) {
                if (!watchlistCollectionNew.contains(watchlistCollectionOldWatchlist)) {
                    watchlistCollectionOldWatchlist.setMovieid(null);
                    watchlistCollectionOldWatchlist = em.merge(watchlistCollectionOldWatchlist);
                }
            }
            for (Watchlist watchlistCollectionNewWatchlist : watchlistCollectionNew) {
                if (!watchlistCollectionOld.contains(watchlistCollectionNewWatchlist)) {
                    Movies oldMovieidOfWatchlistCollectionNewWatchlist = watchlistCollectionNewWatchlist.getMovieid();
                    watchlistCollectionNewWatchlist.setMovieid(movies);
                    watchlistCollectionNewWatchlist = em.merge(watchlistCollectionNewWatchlist);
                    if (oldMovieidOfWatchlistCollectionNewWatchlist != null && !oldMovieidOfWatchlistCollectionNewWatchlist.equals(movies)) {
                        oldMovieidOfWatchlistCollectionNewWatchlist.getWatchlistCollection().remove(watchlistCollectionNewWatchlist);
                        oldMovieidOfWatchlistCollectionNewWatchlist = em.merge(oldMovieidOfWatchlistCollectionNewWatchlist);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = movies.getMovieid();
                if (findMovies(id) == null) {
                    throw new NonexistentEntityException("The movies with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Movies movies;
            try {
                movies = em.getReference(Movies.class, id);
                movies.getMovieid();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The movies with id " + id + " no longer exists.", enfe);
            }
            Collection<Watchlist> watchlistCollection = movies.getWatchlistCollection();
            for (Watchlist watchlistCollectionWatchlist : watchlistCollection) {
                watchlistCollectionWatchlist.setMovieid(null);
                watchlistCollectionWatchlist = em.merge(watchlistCollectionWatchlist);
            }
            em.remove(movies);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Movies> findMoviesEntities() {
        return findMoviesEntities(true, -1, -1);
    }

    public List<Movies> findMoviesEntities(int maxResults, int firstResult) {
        return findMoviesEntities(false, maxResults, firstResult);
    }

    private List<Movies> findMoviesEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Movies.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Movies findMovies(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Movies.class, id);
        } finally {
            em.close();
        }
    }

    public int getMoviesCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Movies> rt = cq.from(Movies.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
